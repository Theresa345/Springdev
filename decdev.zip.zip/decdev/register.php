<?php
session_start();
$pdo = new PDO("mysql:host=localhost;dbname=Petit_site;charset=utf8", "root", "");
$erreur = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    // sexe envoyé en 'M' ou 'F' dans le formulaire, on convertit en int (0 ou 1)
    $sexe_input = $_POST['sexe'] ?? '';
    $sexe = ($sexe_input === 'F') ? 1 : 0;

    if (strlen($password) < 12) {
        $erreur = "Le mot de passe doit contenir au moins 12 caractères.";
    } elseif ($password !== $confirm) {
        $erreur = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifier unicité email
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            $erreur = "Cet email est déjà utilisé.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare("INSERT INTO users (nom, prenom, email, phone, sexe, access, password)
                                     VALUES (?, ?, ?, ?, ?, 0, ?)");
            $insert->execute([$nom, $prenom, $email, $phone, $sexe, $hash]);

            header("Location: login.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Inscription</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-secondary">

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link active" href="#">Admin</a></li>
        <li class="nav-item"><a class="nav-link active" href="#">Users</a></li>
        <li class="nav-item"><a class="btn btn-success" href="#">Add</a></li>
      </ul>
      <form class="d-flex">
        <a href="login.php" class="btn btn-outline-success">Login <i class="fa-solid fa-user"></i></a>
        <a href="register.php" class="btn ms-3 btn-outline-success">Register</a>
      </form>
    </div>
  </div>
</nav>

<form class="mt-3 p-4 rounded bg-white container" method="POST" style="max-width: 600px;">
  <h1 class="text-center mb-4">Inscription</h1>

  <?php if ($erreur): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($erreur) ?></div>
  <?php endif; ?>

  <input class="form-control mb-2" type="text" name="nom" placeholder="Nom" required value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>">
  <input class="form-control mb-2" type="text" name="prenom" placeholder="Prénom" required value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>">
  <input class="form-control mb-2" type="email" name="email" placeholder="Email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
  <input class="form-control mb-2" type="text" name="phone" placeholder="Téléphone" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

  <div class="mb-3">
    <label class="form-label">Sexe :</label><br>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="sexe" value="M" id="sexeH" required <?= (($_POST['sexe'] ?? '') === 'M' || !isset($_POST['sexe'])) ? 'checked' : '' ?>>
      <label class="form-check-label" for="sexeH">Homme</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="sexe" value="F" id="sexeF" required <?= (($_POST['sexe'] ?? '') === 'F') ? 'checked' : '' ?>>
      <label class="form-check-label" for="sexeF">Femme</label>
    </div>
  </div>

  <input class="form-control mb-2" type="password" name="password" placeholder="Mot de passe (min. 12 caractères)" required>
  <input class="form-control mb-3" type="password" name="confirm" placeholder="Confirmer le mot de passe" required>

  <button class="btn btn-outline-primary w-100" type="submit">S'inscrire</button>
</form>

</body>
</html>
