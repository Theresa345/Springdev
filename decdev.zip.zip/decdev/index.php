<?php
header("Location: register.php");
exit;
