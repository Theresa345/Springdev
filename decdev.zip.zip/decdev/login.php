<?php
session_start();
$pdo = new PDO("mysql:host=localhost;dbname=Petit_site;charset=utf8", "root", "");
$erreur = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['access'] = (int)$user['access']; // 0 = user, 1 = admin
        $_SESSION['sexe'] = (int)$user['sexe']; // 0 = homme, 1 = femme

        header("Location: dashboard.php"); // page après connexion
        exit;
    } else {
        $erreur = "Email ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-secondary">

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link active" href="#">Admin</a></li>
        <li class="nav-item"><a class="nav-link active" href="#">Users</a></li>
        <li class="nav-item"><a class="btn btn-success" href="#">Add</a></li>
      </ul>
      <form class="d-flex">
        <a href="login.php" class="btn btn-outline-success">Login <i class="fa-solid fa-user"></i></a>
        <a href="register.php" class="btn ms-3 btn-outline-success">Register</a>
      </form>
    </div>
  </div>
</nav>

<form class="mt-5 p-4 bg-white rounded container" method="POST" style="max-width: 500px;">
  <h2 class="text-center mb-4">Connexion</h2>

  <?php if ($erreur): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($erreur) ?></div>
  <?php endif; ?>

  <input class="form-control mb-3" type="email" name="email" placeholder="Email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
  <input class="form-control mb-3" type="password" name="password" placeholder="Mot de passe" required>

  <button type="submit" class="btn btn-outline-primary w-100">Se connecter</button>
</form>

</body>
</html>
